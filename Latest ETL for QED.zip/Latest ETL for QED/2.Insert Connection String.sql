


INSERT [dbo].[ODS_DB_Configuration] ([Database_Year], [Database_Name], ConnStr) 
VALUES (2016, N'DeSotoISD_UAT_ODS_2016','Data Source=q4projectsql;Initial Catalog=DeSotoISD_UAT_ODS_2016;Provider=SQLNCLI11.1;Integrated Security=SSPI;Auto Translate=False;')
GO
INSERT [dbo].[ODS_DB_Configuration] ([Database_Year], [Database_Name], ConnStr) 
VALUES (2017, N'DeSotoISD_UAT_ODS_2017','Data Source=q4projectsql;Initial Catalog=DeSotoISD_UAT_ODS_201&;Provider=SQLNCLI11.1;Integrated Security=SSPI;Auto Translate=False;')
GO

SELECT * FROM [ODS_DB_Configuration]


--Notes:
/*---------------------ConnectionString Example:
##for window Authentication

Data Source=ServerNameXXXXXX;Initial Catalog=DBName;Provider=SQLNCLI11.1;Integrated Security=SSPI;Auto Translate=False;


##for SQL authentication:

Data Source=ServerNameXXXXXXX;User ID=XXXXXXX;Password=XXXXXXXX;Initial Catalog=XXXXXXXXDB_Name;Provider=SQLNCLI11.1;Auto Translate=False;
-----------------------------------------------*/


