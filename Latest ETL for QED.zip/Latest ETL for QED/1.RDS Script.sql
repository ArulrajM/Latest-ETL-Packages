

/****** Object:  Table [dbo].[YTDTeachersAttendanceEvents]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'YTDTeachersAttendanceEvents')
BEGIN
	DROP TABLE [dbo].[YTDTeachersAttendanceEvents]
END
GO
 
/****** Object:  Table [dbo].[YTDTeachersAttendanceCalendar]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'YTDTeachersAttendanceCalendar')
BEGIN
	DROP TABLE [dbo].[YTDTeachersAttendanceCalendar]
END
GO
 
/****** Object:  Table [dbo].[YTDStudentsDisciplineIncidents]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'YTDStudentsDisciplineIncidents')
BEGIN
	DROP TABLE [dbo].[YTDStudentsDisciplineIncidents]
END
GO
 
/****** Object:  Table [dbo].[YTDStudentsCourseSectionAttendanceEvents]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'YTDStudentsCourseSectionAttendanceEvents')
BEGIN
	DROP TABLE [dbo].[YTDStudentsCourseSectionAttendanceEvents]
END
GO

 
/****** Object:  Table [dbo].[YTDStudentsAttendanceEvents]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'YTDStudentsAttendanceEvents')
BEGIN
	DROP TABLE [dbo].[YTDStudentsAttendanceEvents]
END
GO
 
/****** Object:  Table [dbo].[YTDStudentsAttendanceDisciplineCalendar]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'YTDStudentsAttendanceDisciplineCalendar')
BEGIN
	DROP TABLE [dbo].[YTDStudentsAttendanceDisciplineCalendar]
END
GO
 
/****** Object:  Table [dbo].[YTDStudentsAttendanceCalendar_New]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'YTDStudentsAttendanceCalendar_New')
BEGIN
	DROP TABLE [dbo].[YTDStudentsAttendanceCalendar_New]
END
GO
 
/****** Object:  Table [dbo].[YTDStudentsAttendanceCalendar_Backup]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'YTDStudentsAttendanceCalendar_Backup')
BEGIN
	DROP TABLE [dbo].[YTDStudentsAttendanceCalendar_Backup]
END
GO
 
/****** Object:  Table [dbo].[YTDStudentsAttendanceCalendar]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'YTDStudentsAttendanceCalendar')
BEGIN
	DROP TABLE [dbo].[YTDStudentsAttendanceCalendar]
END
GO
 
/****** Object:  Table [dbo].[YTDStaffAttendanceEvents]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'YTDStaffAttendanceEvents')
BEGIN
	DROP TABLE [dbo].[YTDStaffAttendanceEvents]
END
GO
 
/****** Object:  Table [dbo].[YTDStaffAttendanceCalendar]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'YTDStaffAttendanceCalendar')
BEGIN
	DROP TABLE [dbo].[YTDStaffAttendanceCalendar]
END
GO
 
/****** Object:  Table [dbo].[WORKINGDAYS]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'WORKINGDAYS')
BEGIN
	DROP TABLE [dbo].[WORKINGDAYS]
END
GO
 
/****** Object:  Table [dbo].[TermDuration]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'TermDuration')
BEGIN
	DROP TABLE [dbo].[TermDuration]
END
GO
 
/****** Object:  Table [dbo].[TempPrevGrade]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'TempPrevGrade')
BEGIN
	DROP TABLE [dbo].[TempPrevGrade]
END
GO
 
/****** Object:  Table [dbo].[TempPrevGP]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'TempPrevGP')
BEGIN
	DROP TABLE [dbo].[TempPrevGP]
END
GO
 
/****** Object:  Table [dbo].[TempPeriodSequence]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'TempPeriodSequence')
BEGIN
	DROP TABLE [dbo].[TempPeriodSequence]
END
GO
 
/****** Object:  Table [dbo].[TempNullGradeNoMatch]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'TempNullGradeNoMatch')
BEGIN
	DROP TABLE [dbo].[TempNullGradeNoMatch]
END
GO
 
/****** Object:  Table [dbo].[TempNullGrade]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'TempNullGrade')
BEGIN
	DROP TABLE [dbo].[TempNullGrade]
END
GO
 
/****** Object:  Table [dbo].[TempMissingPS]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'TempMissingPS')
BEGIN
	DROP TABLE [dbo].[TempMissingPS]
END
GO
 
/****** Object:  Table [dbo].[TempMaxGP]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'TempMaxGP')
BEGIN
	DROP TABLE [dbo].[TempMaxGP]
END
GO
 
/****** Object:  Table [dbo].[TempGrade]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'TempGrade')
BEGIN
	DROP TABLE [dbo].[TempGrade]
END
GO
 
/****** Object:  Table [dbo].[TempGPTrend]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'TempGPTrend')
BEGIN
	DROP TABLE [dbo].[TempGPTrend]
END
GO
 
/****** Object:  Table [dbo].[TempBase]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'TempBase')
BEGIN
	DROP TABLE [dbo].[TempBase]
END
GO
 
/****** Object:  Table [dbo].[Teachers]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'Teachers')
BEGIN
	DROP TABLE [dbo].[Teachers]
END
GO
 
/****** Object:  Table [dbo].[TeacherCourseSections]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'TeacherCourseSections')
BEGIN
	DROP TABLE [dbo].[TeacherCourseSections]
END
GO
 
/****** Object:  Table [dbo].[StudInterventionAnalysis]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'StudInterventionAnalysis')
BEGIN
	DROP TABLE [dbo].[StudInterventionAnalysis]
END
GO
 
/****** Object:  Table [dbo].[StudGrowthPlanning]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'StudGrowthPlanning')
BEGIN
	DROP TABLE [dbo].[StudGrowthPlanning]
END
GO
 
/****** Object:  Table [dbo].[StudentsCourseSections]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'StudentsCourseSections')
BEGIN
	DROP TABLE [dbo].[StudentsCourseSections]
END
GO
 
/****** Object:  Table [dbo].[Students_old]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'Students_old')
BEGIN
	DROP TABLE [dbo].[Students_old]
END
GO
 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'Students')
	DROP TABLE [dbo].[Students]
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'Students_History')
	DROP TABLE [dbo].[Students_History]
GO

/****** Object:  Table [dbo].[Staff]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'Staff')
BEGIN
	DROP TABLE [dbo].[Staff]
END
GO
 
/****** Object:  Table [dbo].[Schools]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'Schools')
BEGIN
	DROP TABLE [dbo].[Schools]
END
GO
 
/****** Object:  Table [dbo].[SchoolDistricts]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'SchoolDistricts')
BEGIN
	DROP TABLE [dbo].[SchoolDistricts]
END
GO
 
/****** Object:  Table [dbo].[Parents]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'Parents')
BEGIN
	DROP TABLE [dbo].[Parents]
END
GO
 
/****** Object:  Table [dbo].[LocalAssessmentsItemWise]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'LocalAssessmentsItemWise')
BEGIN
	DROP TABLE [dbo].[LocalAssessmentsItemWise]
END
GO
 
/****** Object:  Table [dbo].[LocalAssessments]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'LocalAssessments')
BEGIN
	DROP TABLE [dbo].[LocalAssessments]
END
GO
 
/****** Object:  Table [dbo].[LexileScores]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'LexileScores')
BEGIN
	DROP TABLE [dbo].[LexileScores]
END
GO
 
/****** Object:  Table [dbo].[IQRGrades]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'IQRGrades')
BEGIN
	DROP TABLE [dbo].[IQRGrades]
END
GO
 
/****** Object:  Table [dbo].[InstructionalDays]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'InstructionalDays')
BEGIN
	DROP TABLE [dbo].[InstructionalDays]
END
GO
 
/****** Object:  Table [dbo].[Holidays]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'Holidays')
BEGIN
	DROP TABLE [dbo].[Holidays]
END
GO
 
/****** Object:  Table [dbo].[GraduationPlanDetails]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'GraduationPlanDetails')
BEGIN
	DROP TABLE [dbo].[GraduationPlanDetails]
END
GO
 
/****** Object:  Table [dbo].[EOCSubjects]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'EOCSubjects')
BEGIN
	DROP TABLE [dbo].[EOCSubjects]
END
GO
 
/****** Object:  Table [dbo].[EOCExams]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'EOCExams')
BEGIN
	DROP TABLE [dbo].[EOCExams]
END
GO
 
/****** Object:  Table [dbo].[EnrolledCredits]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'EnrolledCredits')
BEGIN
	DROP TABLE [dbo].[EnrolledCredits]
END
GO
 
/****** Object:  Table [dbo].[DistrictAdmins]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'DistrictAdmins')
BEGIN
	DROP TABLE [dbo].[DistrictAdmins]
END
GO
 
/****** Object:  Table [dbo].[Clients]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'Clients')
BEGIN
	DROP TABLE [dbo].[Clients]
END
GO
 
/****** Object:  Table [dbo].[Calendar]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'Calendar')
BEGIN
	DROP TABLE [dbo].[Calendar]
END
GO
 
/****** Object:  Table [dbo].[AttendancePeriods]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AttendancePeriods')
BEGIN
	DROP TABLE [dbo].[AttendancePeriods]
END
GO
 
/****** Object:  Table [dbo].[AttendanceDiscipline]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AttendanceDiscipline')
BEGIN
	DROP TABLE [dbo].[AttendanceDiscipline]
END
GO
 
/****** Object:  Table [dbo].[AcademicYears]    Script Date: 11/30/2016 4:30:46 AM ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AcademicYears')
BEGIN
	DROP TABLE [dbo].[AcademicYears]
END
GO


/****** Object:  Table [dbo].[AcademicYears]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[AcademicYears](
                [id] [int] IDENTITY(1,1) NOT NULL,
                [AcademicYear] [varchar](50) NULL,
                [StartDate] [date] NULL,
                [EndDate] [date] NULL,
CONSTRAINT [PK_AcademicYears] PRIMARY KEY CLUSTERED
(
                [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[AttendanceDiscipline]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[AttendanceDiscipline](
                [SchoolID] [int] NULL,
                [SchoolName] [nvarchar](200) NULL,
                [TeacherID] [int] NULL,
                [TeacherName] [nvarchar](200) NULL,
                [StudentUSI] [int] NULL,
                [StudentName] [nvarchar](200) NULL,
                [SchoolViolation] [int] NULL,
                [StateOffense] [int] NULL,
                [SchoolCodeOfConduct] [int] NULL,
                [Others] [int] NULL,
                [Attendance] [real] NULL,
                [TotalInstructionalDays] [int] NULL,
                [DaysAbsent] [int] NULL,
                [ClassPeriod] [nvarchar](200) NULL
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[AttendancePeriods]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[AttendancePeriods](
                [id] [int] IDENTITY(1,1) NOT NULL,
                [ClientId] [int] NULL,
                [SchoolDistrictId] [int] NULL,
                [SchoolId] [int] NULL,
                [AcademicYear] [varchar](50) NULL,
                [Term] [varchar](100) NULL,
                [AttendancePeriod] [varchar](50) NULL,
                [BeginDate] [date] NULL,
                [EndDate] [date] NULL,
CONSTRAINT [PK_FallSpringDates] PRIMARY KEY CLUSTERED
(
                [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[Calendar]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[Calendar](
                [CalendarDate] [date] NOT NULL,
                [CalendarYear] [int] NOT NULL,
                [CalendarMonth] [int] NOT NULL,
                [CalendarDay] [int] NOT NULL,
                [DayOfWeekName] [varchar](10) NOT NULL,
                [FirstDateOfWeek] [date] NOT NULL,
                [LastDateOfWeek] [date] NOT NULL,
                [FirstDateOfMonth] [date] NOT NULL,
                [LastDateOfMonth] [date] NOT NULL,
                [FirstDateOfQuarter] [date] NOT NULL,
                [LastDateOfQuarter] [date] NOT NULL,
                [FirstDateOfYear] [date] NOT NULL,
                [LastDateOfYear] [date] NOT NULL,
                [BusinessDay] [bit] NOT NULL,
                [NonBusinessDay] [bit] NOT NULL,
                [Weekend] [bit] NOT NULL,
                [Holiday] [bit] NOT NULL,
                [Weekday] [bit] NOT NULL,
                [CalendarDateDescription] [varchar](50) NULL,
CONSTRAINT [PK_Calendar] PRIMARY KEY CLUSTERED
(
                [CalendarDate] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[Clients]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[Clients](
                [id] [int] IDENTITY(1,1) NOT NULL,
                [ClientName] [varchar](100) NULL,
CONSTRAINT [PK_Clients] PRIMARY KEY CLUSTERED
(
                [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[DistrictAdmins]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[DistrictAdmins](
                [id] [int] IDENTITY(1,1) NOT NULL,
                [ClientId] [int] NULL,
                [SchoolDistrictId] [int] NULL,
				[Staff_StateUniqueID] nvarchar(60),
                [StaffId] [int] NULL,
                [StaffName] [varchar](100) NULL,
                [Gender] [varchar](6) NULL,
                [PositionTitle] [varchar](50) NULL,
CONSTRAINT [PK_Admins] PRIMARY KEY CLUSTERED
(
                [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[EnrolledCredits]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[EnrolledCredits](
                [SchoolID] [int] NULL,
                [Schoolname] [nvarchar](500) NULL,
                [SchoolYear] [int] NULL,
                [StudentUSI] [int] NULL,
                [StudentName] [nvarchar](300) NULL,
                [AcademicSubjectDescriptorID] [int] NULL,
                [Subject] [nvarchar](200) NULL,
                [Course] [nvarchar](300) NULL,
                [RequiredCredits] [decimal](8, 2) NULL,
                [EarnedCredits] [decimal](8, 2) NULL,
                [TermDescriptorID] [int] NULL,
                [Status] [nvarchar](100) NULL,
                [GradeEarned] [nvarchar](10) NULL,
                [Semester] [nvarchar](200) NULL
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[EOCExams]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[EOCExams](
                [SchoolID] [int] NULL,
                [SchoolName] [nvarchar](500) NULL,
				[Student_StateUniqueID] [nvarchar] (60),
                [StudentUSI] [int] NULL,
                [StudentUniqueID] [nvarchar](10) NULL,
                [StudentName] [nvarchar](100) NULL,
                [Subject] [nvarchar](100) NULL,
                [AdministrationDate] [datetime] NULL,
                [Score] [int] NULL,
                [PerformanceLevel] [varchar](200) NULL,
                [Status] [nvarchar](10) NULL
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[EOCSubjects]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[EOCSubjects](
                [Subject] [nvarchar](200) NULL
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[GraduationPlanDetails]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[GraduationPlanDetails](
                [SchoolID] [int] NULL,
                [GraduationPlantypeID] [int] NULL,
                [GraduationPlan] [nvarchar](200) NULL,
                [Subject] [nvarchar](200) NULL,
                [AcademicSubjectDescriptorID] [int] NULL,
                [Credits] [decimal](8, 2) NULL
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[Holidays]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[Holidays](
                [id] [int] IDENTITY(1,1) NOT NULL,
                [ClientId] [int] NULL,
                [SchoolDistrictId] [int] NULL,
                [SchoolId] [int] NULL,
                [SchoolAcademicYear] [varchar](50) NULL,
                [HolidayOn] [date] NULL,
CONSTRAINT [PK_Holidays] PRIMARY KEY CLUSTERED
(
                [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[InstructionalDays]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[InstructionalDays](
                [SchoolID] [int] NULL,
                [TotalInstructionalDays] [int] NULL,
                [SchoolName] [nvarchar](500) NULL
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[IQRGrades]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[IQRGrades](
                [Grade] [int] NULL,
                [Measures] [nvarchar](255) NULL,
                [Min] [int] NULL,
                [Max] [int] NULL
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[LexileScores]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[LexileScores](
                [RawScore] [int] NULL,
                [ScaleScore] [int] NULL,
                [Lexile] [nvarchar](255) NULL,
                [Month] [int] NULL,
                [Grade] [int] NULL,
                [GradeLevelDescriptorID] [int] NULL,
                [SchoolYear] [int] NULL
) ON [PRIMARY]
 
GO
 

 
/****** Object:  Table [dbo].[Parents]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[Parents](
                [id] [int] IDENTITY(1,1) NOT NULL,
                [ClientId] [int] NULL,
                [SchoolDistrictId] [int] NULL,
                [SchoolId] [int] NULL,
				[Student_StateUniqueID] [nvarchar](60),
                [StudentUSI] [int] NULL,
                [ParentId] [int] NULL,
                [ParentName] [varchar](100) NULL,
                [RelationType] [varchar](50) NULL,
                [PrimaryContact] [bit] NULL,
                [LivesWith] [bit] NULL,
CONSTRAINT [PK_Parents] PRIMARY KEY CLUSTERED
(
                [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[SchoolDistricts]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[SchoolDistricts](
                [id] [int] IDENTITY(1,1) NOT NULL,
                [ClientId] [int] NULL,
                [LocalEducationAAgencyId] [int] NULL,
                [LocalEducationAgencyName] [varchar](100) NULL,
                [LocalEducationAgencycategory] [varchar](50) NULL,
CONSTRAINT [PK_SchoolDistricts] PRIMARY KEY CLUSTERED
(
                [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[Schools]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[Schools](
                [id] [int] IDENTITY(1,1) NOT NULL,
                [ClientId] [nchar](10) NULL,
                [SchoolDistrictId] [int] NULL,
                [SchoolId] [int] NULL,
                [SchoolName] [varchar](100) NULL,
                [SchoolCategory] [varchar](50) NULL,
                [SchoolType] [varchar](50) NULL,
                [SchoolLevel] [int] NULL,
CONSTRAINT [PK_Schools] PRIMARY KEY CLUSTERED
(
                [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[Staff]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[Staff](
                [id] [int] IDENTITY(1,1) NOT NULL,
                [ClientId] [int] NULL,
                [SchoolDistrictId] [int] NULL,
                [SchoolId] [int] NULL,
				[Staff_StateUniqueID] [nvarchar] (60),
                [StaffId] [int] NULL,
                [StaffName] [varchar](100) NULL,
                [Gender] [varchar](6) NULL,
                [PositionTitle] [varchar](100) NULL,
CONSTRAINT [PK_Staff] PRIMARY KEY CLUSTERED
(
                [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[Students]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[Students](
                [id] [int] IDENTITY(1,1) NOT NULL,
                [ClientId] [nchar](10) NULL,
                [SchoolDistrictId] [int] NULL,
                [SchoolId] [int] NULL,
				[Student_StateUniqueID] [nvarchar](60),
                [StudentUSI] [int] NULL,
                [StudentName] [varchar](100) NULL,
                [Gender] [varchar](6) NULL,
                [BirthDate] [date] NULL,
                [HispanicLatinoEthnicity] [bit] NULL,
                [Race] [varchar](50) NULL,				
                [AtRisk] [tinyint] NULL,
                [EconomicDisadvantaged] [tinyint] NULL,
                [SchoolFoodServicesEligibility] [varchar](50) NULL,
                [HomeLess] [tinyint] NULL,
                [Immigrant] [tinyint] NULL,
                [Migrant] [tinyint] NULL,
                [LimitedEnglishProficiency] [varchar](50) NULL,
                [Overage] [tinyint] NULL,
                [Repeater] [tinyint] NULL,
                [Grade] [varchar](50) NULL,
                [LateEnrollment] [tinyint] NULL,
                [HomeRoom] [varchar](100) NULL,
                [DateofEntryatSchool] [date] NULL,
                [DateofWithdrawal] [date] NULL,
                [GraduationPlan] [varchar](50) NULL,
                [ExpectedGraduationYear] [int] NULL,
                [ProgramName] [varchar](50) NULL,
                [GradeLevel] [int] NULL,
                [StudentUniqueId] [nvarchar](64) NULL,
                [SchoolDistrictName] [nvarchar](200) NULL,
                [SchoolName] [nvarchar](500) NULL,
                [TotalRequiredCredits] [decimal](5, 2) NULL,
                [GraduationPlanTypeID] [int] NULL,
				[Language] nvarchar(30)

) ON [PRIMARY]
 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Students_History](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[AcademicYear] varchar(50),
	[ClientId] [nchar](10) NULL,
	[SchoolDistrictId] [int] NULL,
	[SchoolCategoryID] [int],
	[SchoolId] [int] NULL,
	[Student_StateUniqueID] [nvarchar](60) NULL,
	[StudentUSI] [int] NULL,
	[StudentName] [varchar](100) NULL,
	[Gender] [varchar](6) NULL,
	[BirthDate] [date] NULL,
	[HispanicLatinoEthnicity] [bit] NULL,
	[Race] [varchar](50) NULL,
	[AtRisk] [tinyint] NULL,
	[EconomicDisadvantaged] [tinyint] NULL,
	[SchoolFoodServicesEligibility] [varchar](50) NULL,
	[HomeLess] [tinyint] NULL,
	[Immigrant] [tinyint] NULL,
	[Migrant] [tinyint] NULL,
	[LimitedEnglishProficiency] [varchar](50) NULL,
	[Overage] [tinyint] NULL,
	[Repeater] [tinyint] NULL,
	[Grade] [varchar](50) NULL,
	[LateEnrollment] [tinyint] NULL,
	[HomeRoom] [varchar](100) NULL,
	[DateofEntryatSchool] [date] NULL,
	[DateofWithdrawal] [date] NULL,
	[GraduationPlan] [varchar](50) NULL,
	[ExpectedGraduationYear] [int] NULL,
	[ProgramName] [varchar](50) NULL,
	[GradeLevel] [int] NULL,
	[StudentUniqueId] [nvarchar](64) NULL,
	[SchoolDistrictName] [nvarchar](200) NULL,
	[SchoolCategory]	[varchar] (50),
	[SchoolName] [nvarchar](500) NULL,
	[TotalRequiredCredits] [decimal](5, 2) NULL,
	[GraduationPlanTypeID] [int] NULL,
	[Language] [nvarchar](30) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


/****** Object:  Table [dbo].[StudentsCourseSections]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[StudentsCourseSections](
                [id] [int] IDENTITY(1,1) NOT NULL,
                [ClientId] [nchar](10) NULL,
                [SchoolDistrictId] [int] NULL,
                [SchoolId] [int] NULL,
				[Student_StateUniqueID] nvarchar(60),
                [StudentUSI] [int] NULL,
				[Teacher_StateUniqueID] nvarchar(60),
                [TeacherId] [int] NULL,
                [SectionCode] [varchar](50) NULL,
CONSTRAINT [PK_StudentsCourseSections] PRIMARY KEY CLUSTERED
(
                [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[StudGrowthPlanning]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[StudGrowthPlanning](
                [SchoolID] [int] NULL,
                [StaffUSI] [int] NULL,
                [StaffName] [nvarchar](200) NULL,
                [AcademicSubjectDescriptorID] [int] NULL,
                [Subject] [nvarchar](200) NULL,
                [Section] [nvarchar](200) NULL,
                [Student_StateUniqueID] nvarchar(60),
				[StudentUniqueID] [nvarchar](200) NULL,
                [StudentUSI] [int] NULL,
                [StudentName] [nvarchar](200) NULL,
                [CFAAdministrationDate] [date] NULL,
                [CFAScore] [int] NULL,
                [CFAPerformanceLevelMet] [int] NULL,
                [BMAdministrationDate] [date] NULL,
                [BMScore] [int] NULL,
                [BMPerformanceLevelMet] [int] NULL,
                [PSAdministrationDate] [date] NULL,
                [PSScore] [int] NULL,
                [PSLexileScore] [varchar](10) NULL,
                [PSPerformanceLevelMet] [int] NULL,
                [LSAdministrationDate] [date] NULL,
                [LSScore] [int] NULL,
                [LSLexileScore] [varchar](10) NULL,
                [LSPerformanceLevelMet] [int] NULL,
                [AssessmentGrade] [varchar](100) NULL
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[StudInterventionAnalysis]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[StudInterventionAnalysis](
                [SchoolID] [int] NULL,
                [Staff_StateUniqueID] nvarchar(60),                
			    [StaffUSI] [int] NULL,
                [StaffName] [nvarchar](200) NULL,
                [AcademicSubjectDescriptorID] [int] NULL,
                [Subject] [nvarchar](200) NULL,
                [Section] [nvarchar](200) NULL,
				[Student_StateUniqueID] nvarchar(60), 
                [StudentUniqueID] [nvarchar](200) NULL,
                [StudentUSI] [int] NULL,
                [StudentName] [nvarchar](200) NULL,
                [ESL] [int] NULL,
                [LEP] [varchar](50) NULL,
                [SpecialEd] [int] NULL,
                [CFAAdministrationDate] [date] NULL,
                [CFAScore] [int] NULL,
                [CFAPerformanceLevelMet] [int] NULL,
                [BMAdministrationDate] [date] NULL,
                [BMScore] [int] NULL,
                [BMPerformanceLevelMet] [int] NULL,
                [PSAdministrationDate] [date] NULL,
                [PSScore] [int] NULL,
                [PSLexileScore] [varchar](10) NULL,
                [PSPerformanceLevelMet] [int] NULL,
                [LSAdministrationDate] [date] NULL,
                [LSScore] [int] NULL,
                [LSLScore] [varchar](10) NULL,
                [LSLexileScore] [varchar](50) NULL,
                [LSPerformanceLevelMet] [int] NULL,
                [LiStAdministrationDate] [date] NULL,
                [LiStScore] [varchar](10) NULL,
                [LiStScoreForCalc] [varchar](10) NULL,
                [LiStPerformanceLevelMet] [int] NULL,
                [LiStIQRGrades] [nvarchar](100) NULL,
                [LiStTier] [int] NULL,
                [MiStAdministrationDate] [date] NULL,
                [MiStScore] [varchar](10) NULL,
                [MiStScoreForCalc] [varchar](10) NULL,
                [MiStPerformanceLevelMet] [int] NULL,
                [MiStIQRGrades] [nvarchar](100) NULL,
                [MiStTier] [int] NULL,
                [AssessmentGrade] [varchar](100) NULL,
                [LatestCourseGrade] [varchar](100) NULL,
                [NumericGradeEarned] [decimal](6, 2) NULL
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[TeacherCourseSections]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[TeacherCourseSections](
                [id] [int] IDENTITY(1,1) NOT NULL,
                [ClientId] [nchar](10) NULL,
                [SchoolDistrictId] [int] NULL,
                [SchoolId] [int] NULL,
                [CourseID] [varchar](100) NULL,
                [CourseName] [varchar](100) NULL,
                [CourseSubject] [varchar](50) NULL,
                [CourseGrade] [varchar](50) NULL,
                [SchoolYear] [varchar](20) NULL,
                [SchoolTerm] [varchar](10) NULL,
                [ClassPeriod] [varchar](50) NULL,
                [ClassRoomLocation] [varchar](50) NULL,
                [SectionCode] [varchar](50) NULL,
				[Teacher_StateUniqueID] [nvarchar](60),
                [TeacherId] [int] NULL,
CONSTRAINT [PK_CourseSections] PRIMARY KEY CLUSTERED
(
                [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[Teachers]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[Teachers](
                [id] [int] IDENTITY(1,1) NOT NULL,
                [ClientId] [nchar](10) NULL,
                [SchoolDistrictId] [int] NULL,
                [SchoolId] [int] NULL,
				[Teacher_StateUniqueID] nvarchar(60),
                [TeacherId] [int] NULL,
                [TeacherName] [varchar](100) NULL,
                [Gender] [varchar](6) NULL,
                [YearsofProfessionalExperience] [int] NULL,
                [HighestLevelofQualification] [varchar](50) NULL,
                [PositionTitle] [varchar](100) NULL,
CONSTRAINT [PK_Teachers] PRIMARY KEY CLUSTERED
(
                [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[TempBase]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[TempBase](
                [Student_StateUniqueID] nvarchar(60),
				[StudentUSI] [int] NULL,
                [SchoolId] [int] NULL,
                [TermType] [nvarchar](20) NULL,
                [LocalCourseCode] [nvarchar](60) NULL,
                [GradingPeriod] [int] NULL,
                [NumericGradeEarned] [decimal](9, 2) NULL,
                [LetterGradeEarned] [nvarchar](20) NULL
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[TempGPTrend]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[TempGPTrend](
                [Student_StateUniqueID] nvarchar(60),
                [StudentUSI] [int] NOT NULL,
                [SchoolId] [int] NOT NULL,
                [TermType] [nvarchar](20) NOT NULL,
                [LocalCourseCode] [nvarchar](60) NOT NULL,
                [MaxGradingPeriod] [int] NOT NULL,
                [TrendDirection] [int] NULL
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[TempGrade]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[TempGrade](
                [Student_StateUniqueID] nvarchar(60),
                [StudentUSI] [int] NULL,
                [SchoolId] [int] NULL,
                [TermType] [nvarchar](20) NULL,
                [LocalCourseCode] [nvarchar](60) NULL,
                [MaxGradingPeriod] [int] NULL,
                [PriorGradingPeriod] [int] NULL,
                [MaxGPNumericGradeEarned] [decimal](9, 2) NULL,
                [MaxGPLetterGradeEarned] [nvarchar](20) NULL
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[TempMaxGP]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[TempMaxGP](
				[Student_StateUniqueID] nvarchar(60),
                [StudentUSI] [int] NULL,
                [SchoolId] [int] NULL,
                [TermType] [nvarchar](20) NULL,
                [LocalCourseCode] [nvarchar](60) NULL,
                [MaxGradingPeriod] [int] NULL
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[TempMissingPS]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[TempMissingPS](
				[Student_StateUniqueID] nvarchar(60),
                [StudentUSI] [int] NULL,
                [SchoolId] [int] NULL,
                [TermType] [nvarchar](20) NULL,
                [LocalCourseCode] [nvarchar](60) NULL,
                [PeriodSequence] [int] NULL,
                [TermTypeUI] [int] NULL
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[TempNullGrade]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[TempNullGrade](
				[Student_StateUniqueID] nvarchar(60),
                [StudentUSI] [int] NULL,
                [SchoolId] [int] NULL,
                [TermTypeId] [int] NULL,
                [LocalCourseCode] [nvarchar](60) NULL,
                [PeriodSequence] [int] NULL,
                [GradeLevelTypeId] [nvarchar](30) NULL,
                [TermType] [nvarchar](50) NULL,
                [ShortTermType] [nvarchar](20) NULL,
                [NumericGradeEarned] [decimal](9, 2) NULL,
                [LetterGradeEarned] [nvarchar](20) NULL,
                [AvailableCredit] [decimal](18, 4) NULL,
                [Instructor] [nvarchar](100) NULL
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[TempNullGradeNoMatch]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[TempNullGradeNoMatch](
				[Student_StateUniqueID] nvarchar(60),
                [StudentUSI] [int] NULL,
                [SchoolId] [int] NULL,
                [TermTypeId] [int] NULL,
                [LocalCourseCode] [nvarchar](60) NULL,
                [PeriodSequence] [int] NULL,
                [GradeLevelTypeId] [nvarchar](30) NULL,
                [TermType] [nvarchar](50) NULL,
                [ShortTermType] [nvarchar](20) NULL,
                [NumericGradeEarned] [decimal](9, 2) NULL,
                [LetterGradeEarned] [nvarchar](20) NULL,
                [AvailableCredit] [decimal](18, 4) NULL,
                [Instructor] [nvarchar](100) NULL
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[TempPeriodSequence]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[TempPeriodSequence](
                [EducationOrganizationId] [int] NULL,
                [PeriodSequence] [int] NULL,
                [TermTypeUI] [int] NULL,
                [TermType] [varchar](50) NULL,
                [TermTypeId] [int] NULL,
                [GradingPeriodTypeID] [int] NULL
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[TempPrevGP]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[TempPrevGP](
				[Student_StateUniqueID] nvarchar(60),
                [StudentUSI] [int] NULL,
                [SchoolId] [int] NULL,
                [TermType] [nvarchar](20) NULL,
                [LocalCourseCode] [nvarchar](60) NULL,
                [MaxGradingPeriod] [int] NULL,
                [PriorGradingPeriod] [int] NULL
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[TempPrevGrade]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[TempPrevGrade](
				[Student_StateUniqueID] nvarchar(60),
                [StudentUSI] [int] NULL,
                [SchoolId] [int] NULL,
                [TermType] [nvarchar](20) NULL,
                [LocalCourseCode] [nvarchar](60) NULL,
                [MaxGradingPeriod] [int] NULL,
                [PriorGradingPeriod] [int] NULL,
                [MaxGPNumericGradeEarned] [decimal](9, 2) NULL,
                [MaxGPLetterGradeEarned] [nvarchar](20) NULL,
                [PrevNumericGradeEarned] [decimal](9, 2) NULL,
                [PrevLetterGradeEarned] [nvarchar](20) NULL
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[TermDuration]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[TermDuration](
                [id] [int] IDENTITY(1,1) NOT NULL,
                [SchoolID] [int] NOT NULL,
                [AcademicYear] [varchar](50) NULL,
                [TermName] [varchar](50) NULL,
                [BeginDate] [date] NULL,
                [EndDate] [date] NULL,
CONSTRAINT [PK_TermDuration] PRIMARY KEY CLUSTERED
(
                [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
 
GO
 
/****** Object:  Table [dbo].[WORKINGDAYS]    Script Date: 11/30/2016 4:30:46 AM ******/
SET ANSI_NULLS ON
GO
 
SET QUOTED_IDENTIFIER ON
GO
 
CREATE TABLE [dbo].[WORKINGDAYS](
                [SchoolId] [int] NULL,
                [CalendarDate] [date] NOT NULL
) ON [PRIMARY]
 
GO
 

-------------------------------------Reports table

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'ODS_DB_Configuration')
BEGIN
	DROP TABLE ODS_DB_Configuration
END
GO

CREATE TABLE [dbo].[ODS_DB_Configuration](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Database_Year] [int] NOT NULL,
	[Database_Name] [nvarchar](100) NOT NULL,
	[ConnStr] varchar(3000),
	[Active] bit default(1)
) ON [PRIMARY]

GO


ALTER TABLE [dbo].[ODS_DB_Configuration] ADD  CONSTRAINT [PK_ODS_DB_Configuration] PRIMARY KEY NONCLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO

ALTER TABLE [dbo].[ODS_DB_Configuration] ADD  CONSTRAINT [UK_ODS_DB_Configuration_Name] UNIQUE NONCLUSTERED 
(
	[Database_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

ALTER TABLE [dbo].[ODS_DB_Configuration] ADD  CONSTRAINT [UK_ODS_DB_Configuration_Year] UNIQUE NONCLUSTERED 
(
	[Database_Year] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

GO

---------------------------------

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'stg_Clients')
BEGIN
	DROP TABLE stg_Clients
END
GO

CREATE TABLE [dbo].[stg_Clients](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[ClientName] [varchar](100) NULL,
 CONSTRAINT [PK_stg_Clients] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'stg_DistrictAdmins')
BEGIN
	DROP TABLE stg_DistrictAdmins
END
GO
CREATE TABLE [dbo].[stg_DistrictAdmins](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[ClientId] [int] NULL,
	[SchoolDistrictId] [int] NULL,
	[Staff_StateUniqueID] nvarchar(60),
	[StaffId] [int] NULL,
	[StaffName] [varchar](100) NULL,
	[Gender] [varchar](6) NULL,
	[PositionTitle] [varchar](50) NULL,
 CONSTRAINT [PK_stg_Admins] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'stg_Parents')
BEGIN
	DROP TABLE stg_Parents
END
GO
CREATE TABLE [dbo].[stg_Parents](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[ClientId] [int] NULL,
	[SchoolDistrictId] [int] NULL,
	[SchoolId] [int] NULL,
	[Student_StateUniqueID] nvarchar(60),
	[StudentUSI] [int] NULL,
	[ParentId] [int] NULL,
	[ParentName] [varchar](100) NULL,
	[RelationType] [varchar](50) NULL,
	[PrimaryContact] [bit] NULL,
	[LivesWith] [bit] NULL,
 CONSTRAINT [PK_stg_Parents] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'stg_SchoolDistricts')
BEGIN
	DROP TABLE stg_SchoolDistricts
END
GO
CREATE TABLE [dbo].[stg_SchoolDistricts](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[ClientId] [int] NULL,
	[LocalEducationAAgencyId] [int] NULL,
	[LocalEducationAgencyName] [varchar](100) NULL,
	[LocalEducationAgencycategory] [varchar](50) NULL,
 CONSTRAINT [PK_stg_SchoolDistricts] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'stg_Schools')
BEGIN
	DROP TABLE stg_Schools
END
GO
CREATE TABLE [dbo].[stg_Schools](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[ClientId] [nchar](10) NULL,
	[SchoolDistrictId] [int] NULL,
	[SchoolId] [int] NULL,
	[SchoolName] [varchar](100) NULL,
	[SchoolCategory] [varchar](50) NULL,
	[SchoolType] [varchar](50) NULL,
	[SchoolLevel] [int] NULL,
 CONSTRAINT [PK_stg_Schools] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'stg_Staff')
BEGIN
	DROP TABLE stg_Staff
END
GO
CREATE TABLE [dbo].[stg_Staff](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[ClientId] [int] NULL,
	[SchoolDistrictId] [int] NULL,
	[SchoolId] [int] NULL,
	[Staff_StateUniqueID] [nvarchar](60),
	[StaffId] [int] NULL,
	[StaffName] [varchar](100) NULL,
	[Gender] [varchar](6) NULL,
	[PositionTitle] [varchar](100) NULL,
 CONSTRAINT [PK_stg_Staff] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'stg_Students')
BEGIN
	DROP TABLE stg_Students
END
GO
CREATE TABLE [dbo].[stg_Students](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[AcademicYear] varchar(50),
	[ClientId] [nchar](10) NULL,
	[SchoolDistrictId] [int] NULL,
	[SchoolCategoryID] [int],
	[SchoolId] [int] NULL,
	[Student_StateUniqueID] [nvarchar](60),
	[StudentUSI] [int] NULL,
	[StudentName] [varchar](100) NULL,
	[Gender] [varchar](6) NULL,
	[BirthDate] [date] NULL,
	[HispanicLatinoEthnicity] [bit] NULL,
	[Race] [varchar](50) NULL,
	[AtRisk] [tinyint] NULL,
	[EconomicDisadvantaged] [tinyint] NULL,
	[SchoolFoodServicesEligibility] [varchar](50) NULL,
	[HomeLess] [tinyint] NULL,
	[Immigrant] [tinyint] NULL,
	[Migrant] [tinyint] NULL,
	[LimitedEnglishProficiency] [varchar](50) NULL,
	[Overage] [tinyint] NULL,
	[Repeater] [tinyint] NULL,
	[Grade] [varchar](50) NULL,
	[LateEnrollment] [tinyint] NULL,
	[HomeRoom] [varchar](100) NULL,
	[DateofEntryatSchool] [date] NULL,
	[DateofWithdrawal] [date] NULL,
	[GraduationPlan] [varchar](50) NULL,
	[ExpectedGraduationYear] [int] NULL,
	[ProgramName] [varchar](50) NULL,
	[GradeLevel] [int] NULL,
	[StudentUniqueId] [nvarchar](64) NULL,
	[SchoolDistrictName] [nvarchar](200) NULL,
	[SchoolCategory]	[varchar] (50),
	[SchoolName] [nvarchar](500) NULL,
	[TotalRequiredCredits] [decimal](5, 2) NULL,
	[GraduationPlanTypeID] [int] NULL,
	[Language] nvarchar(30)
) ON [PRIMARY]

GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'stg_Teachers')
BEGIN
	DROP TABLE stg_Teachers
END
GO
CREATE TABLE [dbo].[stg_Teachers](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[ClientId] [nchar](10) NULL,
	[SchoolDistrictId] [int] NULL,
	[SchoolId] [int] NULL,
	[Teacher_StateUniqueID] [nvarchar](60),
	[TeacherId] [int] NULL,
	[TeacherName] [varchar](100) NULL,
	[Gender] [varchar](6) NULL,
	[YearsofProfessionalExperience] [int] NULL,
	[HighestLevelofQualification] [varchar](50) NULL,
	[PositionTitle] [varchar](100) NULL,
 CONSTRAINT [PK_stg_Teachers] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO



IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'tmp_Assess')
BEGIN
	DROP TABLE tmp_Assess
END

CREATE TABLE tmp_Assess (
	ClientID INT
	,LocalEducationAgencyID INT
	,SchoolId INT
	,Student_StateUniqueID nvarchar(60)
	,StudentUSi INT
	,AssessmentTitle NVARCHAR(Max)
	,AssessmentCategory NVARCHAR(Max)
	,AcademicSubjectDescriptorId INT
	,GradeLevelDescriptorID INT
	,AcademicSubject NVARCHAR(50)
	,GradeLevel NVARCHAR(30)
	,Version NVARCHAR(20)
	,AdministrationDate DATE
	,AcademicYear NVARCHAR(30)
	,Term VARCHAR(20)
	,AttendancePeriod NVARCHAR(30)
	,AdministrationLanguage NVARCHAR(30)
	,AdministrationEnvironment NVARCHAR(30)
	,RetestIndicator INT
	,ReasonNotTested NVARCHAR(30)
	,MaxRawScore INT
	,ScoreResult INT
	,ResultDataType NVARCHAR(30)
	,AssessmentReportingMethod NVARCHAR(30)
	);

IF EXISTS (SELECT *	FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'tmp_Season')
BEGIN
	DROP TABLE tmp_Season
END

CREATE TABLE tmp_Season (
	ClientID INT
	,[LocalEducationAgencyID] INT
	,SchoolId INT
	,[AcademicYear] VARCHAR(50)
	,[Term] VARCHAR(20)
	,[AttendancePeriod] NVARCHAR(50)
	,BeginDate DATE
	,EndDate DATE
	);

IF EXISTS (SELECT *	FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'tmp_Staff')
BEGIN
	DROP TABLE tmp_Staff
END

CREATE TABLE tmp_Staff (
    Teacher_StateUniqueID nvarchar(60)
	,TeacherUSI INT
	,Student_StateUniqueID nvarchar(60)
	,StudentUSI INT
	,SchoolID INT
	,LocalCourseCode NVARCHAR(100)
	,GradeLevelDescriptorID INT
	,AcademicSubjectDescriptorId INT
	,Description NVARCHAR(200)
	,SectionCode NVARCHAR(100)
	,CourseTitle NVARCHAR(100)
	);


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'tmp_AssessItemwise')
BEGIN
 DROP TABLE tmp_AssessItemwise
END

CREATE TABLE tmp_AssessItemwise (
ClientID int
,LocalEducationAgencyID	int
,SchoolId int
,[Student_StateUniqueID] nvarchar(60)
,StudentUSI int
,AssessmentTitle NVARCHAR(Max)
,AcademicSubjectDescriptorId int
,AssessedGradeLevelDescriptorId	int
,AcademicSubject NVARCHAR(Max)
,AssessedGrade NVARCHAR(50)
,[Version] int
,IdentificationCode	nvarchar(120)
,LearningStandardId	nvarchar(120)
,LearningStandardDescription	nvarchar(MAX)
,AssessmentItemCategory	nvarchar(120)
,CorrectResponse	nvarchar(40)
,AssessmentResponse	nvarchar(120)
,MaxScore int
,AssessmentScoreResult	nvarchar(120)
,AdministrationDate	date);



IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'Staging_LocalAssessments')
BEGIN
	DROP TABLE Staging_LocalAssessments
END

CREATE TABLE [dbo].[Staging_LocalAssessments](
	[ClientID] [int] NULL,
	[LocalEducationAgencyID] [int] NULL,
	[SchoolID] [int] NULL,
	[Student_StateUniqueID] nvarchar(60),
	[StudentUSI] [int] NULL,
	[Teacher_StateUniqueID] nvarchar(60),
	[TeacherUSI] [int] NULL,
	[AssessmentTitle] [varchar](200) NULL,
	[AssessmentCategory] [varchar](50) NULL,
	AcademicSubjectDescriptorId int,
	[AcademicSubject] [varchar](50) NULL,
	[GradeLevel] [varchar](50) NULL,
	[VERSION] [nvarchar](20) NULL,
	[AdministrationDate] [date] NULL,
	[AcademicYear] [varchar](50) NULL,
	[Term] [varchar](20) NULL,
	[AttendancePeriod] [nvarchar](50) NULL,
	[AdministrationLanguage] [nvarchar](30) NULL,
	[AdministrationEnvironment] [nvarchar](30) NULL,
	[RetestIndicator] [int] NULL,
	[ReasonNotTested] [nvarchar](20) NULL,
	[MaxRawScore] [int] NULL,
	[ScoreResult] [int] NULL,
	[ResultDataType] [nvarchar](10) NULL,
	[AssessmentReportingMethod] [nvarchar](30) NULL,
    [SchoolName] [varchar](100) NULL,
    [SchoolDistrictName] [varchar](100) NULL,
	[SchoolCategory] [varchar](50) NULL,
	[StudentName] [varchar](100) NULL,
	[TeacherName] [varchar](100) NULL,
	[YearsofProfessionalExperience] [int] NULL,
	[HighestLevelofQualification] [varchar](50) NULL,
	[CourseTitle] [nvarchar](100) NULL,
	[BeginDate] [date] NULL,
	[EndDate] [date] NULL
) ON [PRIMARY]
GO


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'rpt_LocalAssessments')
BEGIN
	DROP TABLE rpt_LocalAssessments
END

CREATE TABLE [dbo].[rpt_LocalAssessments](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[ClientId] [int] NULL,
	[SchoolDistrictId] [int] NULL,
	[SchoolId] [int] NULL,
	[Student_StateUniqueID] nvarchar(60),
	[StudentUSI] [int] NULL,
	[Teacher_StateUniqueID] nvarchar(60),
	[TeacherUSI] [int] NULL,
	[SectionCode] [varchar](50) NULL,
	[AssessmentId] [int] NULL,
	[AssessmentTitle] [varchar](200) NULL,
	[AssessmentCategory] [varchar](50) NULL,
	[AcademicSubject] [varchar](50) NULL,
	[AssessedGradeLevel] [varchar](50) NULL,
	[Version] [nvarchar](50) NULL,
	[AdministrationDate] [date] NULL,
	[AcademicYear] [varchar](50) NULL,
	[Term] [varchar](50) NULL,
	[AttendancePeriod] [nvarchar](50) NULL,
	[AdministrationLanguage] [nvarchar](50) NULL,
	[AdministrationEnvironment] [nvarchar](50) NULL,
	[RetestIndicator] [varchar](50) NULL,
	[ReasonNotTested] [nvarchar](50) NULL,
	[MaxRawScore] [float] NULL,
	[ScoreResult] [float] NULL,
	[ResultDataType] [nvarchar](10) NULL,
	[AssessmentReportingMethod] [nvarchar](50) NULL,
	[ScoreAverage] [float] NULL,
	SchoolName	varchar(100),
	StudentName	varchar(100),
	SchoolDistrictName	varchar(200),
	TeacherName varchar(100),
	SchoolCategory [varchar](50) NULL,
	YearsofProfessionalExperience	int	,
	HighestLevelofQualification	varchar	(50),
	--[LastScore] int NULL,
	Result VARCHAR(100) NULL,
	CourseTitle NVARCHAR(100)	
 CONSTRAINT [rpt_LocalAssessments_1] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'rpt_LocalAssessmentsItemWise')
BEGIN
	DROP TABLE rpt_LocalAssessmentsItemWise
END

CREATE TABLE [dbo].[rpt_LocalAssessmentsItemWise](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[ClientId] [int] NULL,
	[SchoolDistrictId] [int] NULL,
	[SchoolId] [int] NULL,
	[Student_StateUniqueID] nvarchar(60),
	[StudentUSI] [int] NULL,
	[Teacher_StateUniqueID] nvarchar(60),
	[TeacherUSI] [int] NULL,
	[AssessmentTitle] [varchar](200) NULL,
	[AcademicSubject] [varchar](100) NULL,
	[AssessedGradeLevel] [varchar](50) NULL,
	[Version] [varchar](50) NULL,
	[IdentificationCode] [varchar](50) NULL,
	[LearningStandardId] [nvarchar](50) NULL,
	[LearningStandardDescription] [varchar](max) NULL,
	[AssessmentItemCategory] [varchar](100) NULL,
	[CorrectResponse] [nvarchar](50) NULL,
	[StudentResponse] [nvarchar](50) NULL,
	[MaxRawScore] [int] NULL,
	[Result] [nvarchar](50) NULL,
	[Correct] [int] NULL,
	[AdministrationDate] [date] NULL,
	[AcademicYear] [nvarchar](50) NULL,
	[Term] [varchar](50) NULL,
	[AttendancePeriod] [nvarchar](50) NULL,
	SchoolName	varchar(100),
	StudentName	varchar(100),
	SchoolDistrictName	varchar(200),
	TeacherName varchar(100),
	SchoolCategory [varchar](50) NULL,
	YearsofProfessionalExperience	int	,
	HighestLevelofQualification	varchar	(50),
 CONSTRAINT [rpt_LocalAssessmentsItemWise_New] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'rpt_StudentsDisciplineIncidents')
BEGIN
	DROP TABLE rpt_StudentsDisciplineIncidents
END

CREATE TABLE [dbo].[rpt_StudentsDisciplineIncidents](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[ClientId] [int] NULL,
	[SchoolDistrictId] [int] NULL,
	[SchoolId] [int] NULL,
	[Student_StateUniqueID] nvarchar(60),
	[StudentUSI] [int] NULL,
	[DisciplineIncidentDate] [date] NULL,
	[AcademicYear] [varchar](50) NULL,
	[Term] [varchar](50) NULL,
	[AttendancePeriod] [varchar](50) NULL,
	[DisciplineIncidentIdentifier] [int] NULL,
	[DisciplineIncidentLocation] [varchar](50) NULL,
	[ReporterDescription] [varchar](50) NULL,
	[ReporterName] [varchar](50) NULL,
	[BehaviorType] [varchar](50) NULL,
	[BehaviorDescription] [varchar](500) NULL,
	[Weapon] [varchar](50) NULL,
	[WeaponType] [varchar](50) NULL,
	[ReportedToLawEnforcement] [tinyint] NULL,
	[StudentParticipationCode] [varchar](50) NULL,
	[DisciplineActionTaken] [varchar](50) NULL,
	[SchoolViolation] [tinyint] NULL,
	[StateOffense] [tinyint] NULL,
	[SchoolCodeofConduct] [tinyint] NULL,
	[Others] [tinyint] NULL,
	SchoolName	varchar(100),
	StudentName	varchar(100),
	SchoolDistrictName	varchar(200),
	[Grade] [varchar](50) NULL,
	SchoolCategory [varchar](50) NULL,
 CONSTRAINT [PK_rpt_DisciplineIncidents] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'rpt_StudentsAttendanceDisciplineCalendar')
BEGIN
	DROP TABLE rpt_StudentsAttendanceDisciplineCalendar
END

CREATE TABLE [dbo].[rpt_StudentsAttendanceDisciplineCalendar](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[ClientId] [int] NULL,
	[SchoolDistrictId] [int] NULL,
	[SchoolId] [int] NULL,
	[Student_StateUniqueID] nvarchar(60),
	[StudentUSI] [int] NULL,
	[CalendarDate] [date] NULL,
	[AcademicYear] [varchar](50) NULL,
	[Term] [varchar](50) NULL,
	[AttendancePeriod] [varchar](50) NULL,
	[Present] [tinyint] NULL,
	[ExecusedAbsence] [tinyint] NULL,
	[UnExecusedAbsence] [tinyint] NULL,
	[Tardy] [tinyint] NULL,
	[AttendanceEventCategory] [varchar](50) NULL,
	[DisciplineIncidentIdentifier] [int] NULL,
	[DisciplineIncidentLocation] [varchar](50) NULL,
	[ReporterDescription] [varchar](50) NULL,
	[ReporterName] [varchar](50) NULL,
	[BehaviorType] [varchar](50) NULL,
	[BehaviorDescription] [varchar](50) NULL,
	[Weapon] [varchar](50) NULL,
	[WeaponType] [varchar](50) NULL,
	[ReportedToLawEnforcement] [tinyint] NULL,
	[StudentParticipationCode] [varchar](50) NULL,
	[SchoolViolation] [tinyint] NULL,
	[StateOffense] [tinyint] NULL,
	[SchoolCodeofConduct] [tinyint] NULL,
	[Others] [tinyint] NULL,
	[SchoolName] [varchar](100) NULL,
	[SchoolType] [varchar](50) NULL,
	[SchoolLevel] [int] NULL,
	[Grade] [varchar](50) NULL,
	[Gender] [varchar](6) NULL,
	[BirthDate] [date] NULL,
	[HispanicLatinoEthnicity] [bit] NULL,
	[Race] [varchar](50) NULL,	
	[GradeLevel] [int] NULL,
	[ProgramName] [varchar](50) NULL,
	[StudentName] [varchar](100) NULL,
	SchoolCategory [varchar](50) NULL,
	ScoreResult INT,
	AcademicSubject NVARCHAR(MAX),
	Result VARCHAR(100),	
 CONSTRAINT [PK_RPTStudentsAttendanceDisciplineCalendar] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'rpt_StaffAttendanceEvents')
BEGIN
	DROP TABLE rpt_StaffAttendanceEvents
END

CREATE TABLE [dbo].[rpt_StaffAttendanceEvents](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[ClientId] [int] NOT NULL,
	[SchoolDistrictId] [int] NULL,
	[SchoolId] [int] NULL,
	[Staff_StateUniqueID] nvarchar(60),
	[StaffId] [int] NULL,
	[AttendanceEventDate] [date] NULL,
	[AttendanceEventCategory] [varchar](50) NULL,
	[AttendanceEventReason] [varchar](100) NULL,
	SchoolName	varchar(100),	
	SchoolDistrictName	varchar(200),
	StaffName	varchar(100),
 CONSTRAINT [PK_rpt_StaffAttendanceEvents] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'rpt_StudentsAttendanceEvents')
BEGIN
	DROP TABLE rpt_StudentsAttendanceEvents
END

CREATE TABLE [dbo].[rpt_StudentsAttendanceEvents](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[ClientId] [nchar](10) NULL,
	[SchoolDistrictId] [int] NULL,
	[SchoolId] [int] NULL,
	[Student_StateUniqueID] nvarchar(60),
	[StudentUSI] [int] NULL,
	[AttendanceEventDate] [date] NULL,
	[AttendanceEventCategory] [varchar](50) NULL,
	[AttendanceEventReason] [varchar](100) NULL,
	SchoolName	varchar(100),	
	SchoolDistrictName	varchar(200),
	[StudentName] [varchar](100) NULL,
 CONSTRAINT [PK_rptAttendanceEvents] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'rpt_TeachersAttendanceEvents')
BEGIN
	DROP TABLE rpt_TeachersAttendanceEvents
END

CREATE TABLE [dbo].[rpt_TeachersAttendanceEvents](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[ClientId] [int] NULL,
	[SchoolDistrictId] [int] NULL,
	[SchoolId] [int] NULL,
	[Teacher_StateUniqueID] nvarchar(60),
	[TeacherId] [int] NULL,
	[AttendanceEventDate] [date] NULL,
	[AttendanceEventCategory] [varchar](50) NULL,
	[AttendanceEventReason] [varchar](100) NULL,
	SchoolName	varchar(100),	
	SchoolDistrictName	varchar(200),
	TeacherName varchar(100),
 CONSTRAINT [PK_rpt_TeachersAttendanceEvents_1] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'rpt_StudentsCourseSectionAttendanceEvents')
BEGIN
	DROP TABLE rpt_StudentsCourseSectionAttendanceEvents
END

CREATE TABLE [dbo].[rpt_StudentsCourseSectionAttendanceEvents](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[ClientId] [int] NULL,
	[SchoolDistrictId] [int] NULL,
	[SchoolId] [int] NULL,
	[Student_StateUniqueID] nvarchar(60),
	[Teacher_StateUniqueID] nvarchar(60),
	[StudentUSI] [int] NULL,
	[AttendanceEventDate] [date] NULL,
	[AcademicYear] [varchar](50) NULL,
	[Term] [varchar](50) NULL,
	[AttendancePeriod] [varchar](50) NULL,
	[AttendanceEventCategory] [varchar](50) NULL,
	[AttendanceEventReason] [varchar](100) NULL,
	[EducationalEnvironment] [varchar](50) NULL,
	[SectionCode] [varchar](50) NULL,
	[TeacherName] [varchar](100) NULL,
	[TeacherId] [int] NULL,
	SchoolName	varchar(100),	
	SchoolDistrictName	varchar(200),
	[StudentName] [varchar](100) NULL,
 CONSTRAINT [PK_rptSectionAttendanceEvents] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO



IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'rpt_StudentsAttendanceCalendar')
BEGIN
DROP TABLE [dbo].[rpt_StudentsAttendanceCalendar]
END

CREATE TABLE [dbo].[rpt_StudentsAttendanceCalendar](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[ClientId] [nchar](10) NULL,
	[SchoolDistrictId] [int] NULL,
	[SchoolId] [int] NULL,
	[Student_StateUniqueID] nvarchar(60),
	[StudentUSI] [int] NULL,
	[CalendarDate] [date] NULL,
	[AcademicYear] [varchar](50) NULL,
	[Term] [varchar](50) NULL,
	[AttendancePeriod] [varchar](50) NULL,
	[Present] [tinyint] NULL,
	[ExecusedAbsence] [tinyint] NULL,
	[UnExecusedAbsence] [tinyint] NULL,
	[Tardy] [tinyint] NULL,
	[SchoolName] [varchar](100) NULL,
	[SchoolCategory] [varchar](50) NULL,
	[SchoolType] [varchar](50) NULL,
	[SchoolLevel] [int] NULL,
	[StudentName] [varchar](100) NULL,
	[Gender] [varchar](6) NULL,
	[BirthDate] [date] NULL,
	[HispanicLatinoEthnicity] [bit] NULL,
	[Race] [varchar](50) NULL,
	[Grade] [varchar](50) NULL,
	[ProgramName] [varchar](50) NULL,
	[GradeLevel] [int] NULL,
	[SchoolDistrictName] [varchar](200) NULL,
	[AttendanceEventCategory] [varchar](50) NULL
) ON [PRIMARY]

GO


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'tmp_Result')
BEGIN
DROP TABLE [dbo].[tmp_Result]
END
CREATE TABLE [tmp_Result] (
	[SchoolDistrictId] int,  
    [SchoolID] int,
	[Student_StateUniqueID] nvarchar(60),
    [StudentUSI] int,   
    [AcademicSubjectDescriptorId] int,
    [AssessmentTitle] nvarchar(max),
	[AssessedGradeLevelDescriptorId] int,
    [AdministrationDate] date,
    [Version] int,   
	[Result] varchar(4)
)

GO


-------------------Standard Lookup table for STAAR and EOC
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'StandardsLookup')
BEGIN
DROP TABLE [dbo].[StandardsLookup]
END
GO
CREATE TABLE [dbo].[StandardsLookup](
	[GradeLevelDescriptorID] [int] NULL,
	[Grade] [int] NULL,
	[AcademicSubjectDescriptorID] [int] NULL,
	[Subject] [nvarchar](255) NULL,
	[Approach] [int] NULL,
	[Meet] [int] NULL,
	[Master] [int] NULL
) ON [PRIMARY]

GO
INSERT [dbo].[StandardsLookup] ([GradeLevelDescriptorID], [Grade], [AcademicSubjectDescriptorID], [Subject], [Approach], [Meet], [Master]) VALUES (16, 3, 22, N'Mathematics', 1360, 1486, 1596)
INSERT [dbo].[StandardsLookup] ([GradeLevelDescriptorID], [Grade], [AcademicSubjectDescriptorID], [Subject], [Approach], [Meet], [Master]) VALUES (6, 4, 22, N'Mathematics', 1467, 1589, 1670)
INSERT [dbo].[StandardsLookup] ([GradeLevelDescriptorID], [Grade], [AcademicSubjectDescriptorID], [Subject], [Approach], [Meet], [Master]) VALUES (2, 5, 22, N'Mathematics', 1500, 1625, 1724)
INSERT [dbo].[StandardsLookup] ([GradeLevelDescriptorID], [Grade], [AcademicSubjectDescriptorID], [Subject], [Approach], [Meet], [Master]) VALUES (18, 6, 22, N'Mathematics', 1536, 1653, 1772)
INSERT [dbo].[StandardsLookup] ([GradeLevelDescriptorID], [Grade], [AcademicSubjectDescriptorID], [Subject], [Approach], [Meet], [Master]) VALUES (17, 7, 22, N'Mathematics', 1575, 1688, 1798)
INSERT [dbo].[StandardsLookup] ([GradeLevelDescriptorID], [Grade], [AcademicSubjectDescriptorID], [Subject], [Approach], [Meet], [Master]) VALUES (5, 8, 22, N'Mathematics', 1595, 1700, 1854)
INSERT [dbo].[StandardsLookup] ([GradeLevelDescriptorID], [Grade], [AcademicSubjectDescriptorID], [Subject], [Approach], [Meet], [Master]) VALUES (16, 3, 28, N'Reading', 1345, 1468, 1555)
INSERT [dbo].[StandardsLookup] ([GradeLevelDescriptorID], [Grade], [AcademicSubjectDescriptorID], [Subject], [Approach], [Meet], [Master]) VALUES (6, 4, 28, N'Reading', 1434, 1550, 1633)
INSERT [dbo].[StandardsLookup] ([GradeLevelDescriptorID], [Grade], [AcademicSubjectDescriptorID], [Subject], [Approach], [Meet], [Master]) VALUES (2, 5, 28, N'Reading', 1470, 1582, 1667)
INSERT [dbo].[StandardsLookup] ([GradeLevelDescriptorID], [Grade], [AcademicSubjectDescriptorID], [Subject], [Approach], [Meet], [Master]) VALUES (18, 6, 28, N'Reading', 1517, 1629, 1718)
INSERT [dbo].[StandardsLookup] ([GradeLevelDescriptorID], [Grade], [AcademicSubjectDescriptorID], [Subject], [Approach], [Meet], [Master]) VALUES (17, 7, 28, N'Reading', 1567, 1674, 1753)
INSERT [dbo].[StandardsLookup] ([GradeLevelDescriptorID], [Grade], [AcademicSubjectDescriptorID], [Subject], [Approach], [Meet], [Master]) VALUES (5, 8, 28, N'Reading', 1587, 1700, 1783)
INSERT [dbo].[StandardsLookup] ([GradeLevelDescriptorID], [Grade], [AcademicSubjectDescriptorID], [Subject], [Approach], [Meet], [Master]) VALUES (6, 4, 35, N'Writing', 3550, 4000, 4612)
INSERT [dbo].[StandardsLookup] ([GradeLevelDescriptorID], [Grade], [AcademicSubjectDescriptorID], [Subject], [Approach], [Meet], [Master]) VALUES (17, 7, 35, N'Writing', 3550, 4000, 4602)
INSERT [dbo].[StandardsLookup] ([GradeLevelDescriptorID], [Grade], [AcademicSubjectDescriptorID], [Subject], [Approach], [Meet], [Master]) VALUES (2, 5, 24, N'Science', 3550, 4000, 4402)
INSERT [dbo].[StandardsLookup] ([GradeLevelDescriptorID], [Grade], [AcademicSubjectDescriptorID], [Subject], [Approach], [Meet], [Master]) VALUES (5, 8, 24, N'Science', 3550, 4000, 4406)
INSERT [dbo].[StandardsLookup] ([GradeLevelDescriptorID], [Grade], [AcademicSubjectDescriptorID], [Subject], [Approach], [Meet], [Master]) VALUES (5, 8, 31, N'Social Studies', 3550, 4000, 4268)

GO

/****** Object:  Table [dbo].[StandardsLookupEOC]    Script Date: 26-01-2017 16:23:01 ******/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'StandardsLookupEOC')
BEGIN
DROP TABLE [dbo].[StandardsLookupEOC]
END
GO
CREATE TABLE [dbo].[StandardsLookupEOC](
	[Subject] [nvarchar](255) NULL,
	[Approach] [int] NULL,
	[Meet] [int] NULL,
	[Master] [int] NULL
) ON [PRIMARY]


INSERT [dbo].[StandardsLookupEOC] ([Subject], [Approach], [Meet], [Master]) VALUES 
('Algebra I',3550,	4000,	4333)
INSERT [dbo].[StandardsLookupEOC] ([Subject], [Approach], [Meet], [Master]) VALUES 
('Algebra II',	3550,	4000,	4411)
INSERT [dbo].[StandardsLookupEOC] ([Subject], [Approach], [Meet], [Master]) VALUES 
('Biology',	3550,	4000,	4576)
INSERT [dbo].[StandardsLookupEOC] ([Subject], [Approach], [Meet], [Master]) VALUES 
('English I',	3775,	4000,	4691)
INSERT [dbo].[StandardsLookupEOC] ([Subject], [Approach], [Meet], [Master]) VALUES 
('English II',	3775,	4000,	4831)
INSERT [dbo].[StandardsLookupEOC] ([Subject], [Approach], [Meet], [Master]) VALUES 
('English III',	3775,	4000,	4546)
INSERT [dbo].[StandardsLookupEOC] ([Subject], [Approach], [Meet], [Master]) VALUES 
('U.S.History',	3550,	4000,	4440)



----------------------------Staging table for STAAR and EOC
If Object_Id ('dbo.Staging_StudentAssessmentPerformance') IS NOT NULL
Drop Table dbo.Staging_StudentAssessmentPerformance
GO

Create table dbo.Staging_StudentAssessmentPerformance
(
AcademicYear varchar(20),
SchoolId int,
[Student_StateUniqueID] nvarchar(60),
StudentUSI int,
[Subject] nvarchar(200),
AcademicSubjectDescriptorId int,
AdministrationDate Date,
AssessedGradeLevelDescriptorId int,
AssessmentGrade nvarchar(200),
AssessmentTitle nvarchar(300),
AssessmentReportingMethodType nvarchar(200),
ResultDatatypeTypeId int,
Score int,
PerformanceLevelMet int,
[CourseCode] [nvarchar](60)  NULL,
[CourseName] [nvarchar](60)  NULL
)
GO


----------------------------Trans table for STAAR and EOC
If Object_Id ('dbo.rpt_StudentAssessmentPerformance') IS NOT NULL
Drop Table dbo.rpt_StudentAssessmentPerformance
GO

Create table dbo.rpt_StudentAssessmentPerformance
(
AcademicYear varchar(20),
SchoolId int,
SchoolName varchar(100),
[Student_StateUniqueID] nvarchar(60),
StudentUSI int,
StudentName varchar(100),
EconomicDisadvantaged int,
[Subject] nvarchar(200),
AcademicSubjectDescriptorId int,
AdministrationDate Date,
AssessedGradeLevelDescriptorId int,
AssessmentGrade nvarchar(200),
AssessmentTitle nvarchar(300),
AssessmentReportingMethodType nvarchar(200),
ResultDatatypeTypeId int,
Score int,
ApproachesGradeLevel int,
MeetsGradeLevel int,
MastersGradeLevel int,
PerformanceType varchar(20),
PerformanceLevelMet int,
CreatedDate datetime default(getdate())
)
GO


----------------------------Course Enrollment vs Completion
If Object_Id ('dbo.rpt_CourseEnrollmentCompletion') IS NOT NULL
Drop Table dbo.rpt_CourseEnrollmentCompletion
GO

Create table dbo.rpt_CourseEnrollmentCompletion
(
AcademicYear varchar(20),
SchoolId int,
SchoolName varchar(100),
SchoolCategory varchar(50),
ProgramName VARCHAR(50),
EOC nvarchar(200),
EnrolledStudents int,
PassedStudents int,
Passed decimal(5,2)
)
GO


----------------------------ETL Log table
If Object_Id ('dbo.ETLLog') IS NOT NULL
Drop Table dbo.[ETLLog]
GO

CREATE TABLE [dbo].[ETLLog](
	[LogID] [int] IDENTITY(1,1),
	[LogMessage] [varchar](5000) NULL,
	[PackageName] varchar(100) NULL,
	[TaskName] varchar(100) NULL,
	[LogDateTime] [datetime] NULL
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
ALTER TABLE [dbo].[ETLLog] ADD  CONSTRAINT [DF_ETLLog_LogDateTime]  DEFAULT (getdate()) FOR [LogDateTime]
GO

----------------------------Special Programs
If Object_Id ('dbo.Staging_SpecialAssessment') IS NOT NULL
Drop Table dbo.[Staging_SpecialAssessment]
GO

CREATE TABLE [dbo].[Staging_SpecialAssessment](
	[AcademicYear] [varchar](44) NULL,
	[Student_StateUniqueID] nvarchar(60),
	[StudentUSI] [int]  NULL,
	[Subject] [nvarchar](1024) NULL,
	[AcademicSubjectDescriptorId] [int]  NULL,
	[AdministrationDate] [date]  NULL,
	[AssessedGradeLevelDescriptorId] [int]  NULL,
	[AssessmentGrade] [nvarchar](1024) NULL,
	[AssessmentCategoryTypeID] [int]  NULL,
	[AssessmentCategoryType] [nvarchar](1024)  NULL,
	[AssessmentCategory] [varchar](100) NULL,
	[AssessmentTitle] [nvarchar](60) NULL,
	[PerformanceLevelMet] [int]  NULL,
	[Version] INT NULL,
	PerformanceBaseType varchar(50)
) ON [PRIMARY]

GO


----------------------------Temp_StudentCourse
If Object_Id ('dbo.Temp_StudentCourse') IS NOT NULL
Drop Table dbo.[Temp_StudentCourse]
GO

CREATE TABLE [dbo].[Temp_StudentCourse](
	[SchoolId] [int]  NULL,
	[Student_StateUniqueID] nvarchar(60),
	[StudentUSI] [int]  NULL,
	[AcademicSubjectDescriptorId] [int]  NULL,
	[Subject] [nvarchar](60)  NULL,
	[CourseCode] [nvarchar](60)  NULL,
	[CourseTitle] [nvarchar](60)  NULL,
	[CourseName] [nvarchar](60)  NULL
) ON [PRIMARY]




----------------------------Special Programs
If Object_Id ('dbo.Temp_AssessmentResult') IS NOT NULL
Drop Table dbo.[Temp_AssessmentResult]
GO

CREATE TABLE [dbo].[Temp_AssessmentResult](
	[Student_StateUniqueID] [nvarchar](60),
	[StudentUSI] [int]  NULL,	
	[AcademicSubjectDescriptorId] [int]  NULL,	
	[AssessedGradeLevelDescriptorId] [int]  NULL,
	[AssessmentTitle] [nvarchar](60) NULL,
	[Version] INT NULL,	
	[IstationTier] [nvarchar](35) NULL,
	[RawScore] [nvarchar](35) NULL,
	[ScaleScore] [nvarchar](35) NULL,
	[LexileMeasureScore] [nvarchar](35) NULL
) ON [PRIMARY]

GO


-------------------Special Programs
If Object_Id ('dbo.Temp_StudentCourseGrade') IS NOT NULL
Drop Table dbo.[Temp_StudentCourseGrade]
GO

CREATE TABLE [dbo].[Temp_StudentCourseGrade](
	[SchoolId] [int]  NULL,
	[Student_StateUniqueID] [nvarchar](60),
	[StudentUSI] [int]  NULL,
	[AcademicSubjectDescriptorId] [int]  NULL,	
	[LetterSubjectGrade] [nvarchar](20) NULL,
	[NumericSubjectGrade] [decimal](9, 2) NULL
) ON [PRIMARY]

GO


If Object_Id ('dbo.rpt_SpecialAssessment') IS NOT NULL
Drop Table dbo.[rpt_SpecialAssessment]
GO

CREATE TABLE [dbo].[rpt_SpecialAssessment](
	[AcademicYear] [varchar](44) NULL,
	[SchoolId] [int]  NULL,
	[SchoolName] [nvarchar](75)  NULL,
	[Student_StateUniqueID] [nvarchar](60),
	[StudentUSI] [int]  NULL,
	[ProgramName] [varchar](50) NULL,
	--[CourseCode] [nvarchar](60)  NULL,
	--[CourseTitle] [nvarchar](60)  NULL,
	[Subject] [nvarchar](1024) NULL,
	[AcademicSubjectDescriptorId] [int]  NULL,
	[AdministrationDate] [date]  NULL,
	[AssessedGradeLevelDescriptorId] [int]  NULL,
	[AssessmentGrade] [nvarchar](1024) NULL,
	[AssessmentCategoryType] [nvarchar](1024)  NULL,
	[AssessmentType] [varchar](100) NULL,
	[AssessmentCategory] [varchar](100) NULL,
	[AssessmentTitle] [nvarchar](60) NULL,
	[IstationTier] [nvarchar](35) NULL,
	[RawScore] [nvarchar](35) NULL,
	[ScaleScore] [nvarchar](35) NULL,
	[LexileMeasureScore] [nvarchar](35) NULL,
	[LetterSubjectGrade] [nvarchar](20) NULL,
	[NumericSubjectGrade] [decimal](9, 2) NULL,
	[PerformanceLevelMet] [int]  NULL,
	PerformanceBaseType varchar(50)
) ON [PRIMARY]

GO


------------Function
IF OBJECT_ID('udf_GetNumeric', 'FN') IS NOT NULL
    DROP FUNCTION dbo.udf_GetNumeric
GO

CREATE FUNCTION [dbo].[udf_GetNumeric]
(
	@strAlphaNumeric VARCHAR(256)
)
RETURNS VARCHAR(256)
AS
	BEGIN
		DECLARE @intAlpha INT
		SET @intAlpha = PATINDEX('%[^0-9]%', @strAlphaNumeric)
		BEGIN
		WHILE @intAlpha > 0
		BEGIN
			SET @strAlphaNumeric = STUFF(@strAlphaNumeric, @intAlpha, 1, '' )
			SET @intAlpha = PATINDEX('%[^0-9]%', @strAlphaNumeric )
		END
	END
	RETURN ISNULL(@strAlphaNumeric,0)
END

GO

----------------------VIEW


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'vw_assessment_special_program')
	DROP VIEW [dbo].[vw_assessment_special_program]
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'vw_assessment_early_warning_system')
	DROP VIEW [dbo].[vw_assessment_early_warning_system]
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'V_LocalAssessments_Score')
	DROP VIEW [dbo].[V_LocalAssessments_Score]
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'V_LocalAssessments')
	DROP VIEW [dbo].[V_LocalAssessments]
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'VW_State_Assessment_Student_Performance_All_New')
	DROP VIEW [dbo].[VW_State_Assessment_Student_Performance_All_New]
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'VW_State_Assessment_Student_Performance_New')
	DROP VIEW [dbo].[VW_State_Assessment_Student_Performance_New]
GO


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'vw_Performance_LevelBy_Demographic_Assessment')
	DROP VIEW [dbo].[vw_Performance_LevelBy_Demographic_Assessment]
GO



CREATE View [dbo].[VW_State_Assessment_Student_Performance_New]

AS

SELECT count([EconomicDisadvantaged]) Total_Test_Count,S.SchoolName,'T' As TotalType, AcademicYear As Academicyear,

'Total Tests' AS 'Satisfactory Standard',SchoolCategory ,   AssessmentGrade ,SP.subject AS Subject

FROM [dbo].rpt_StudentAssessmentPerformance AS SP

INNER JOIN schools S ON S.SchoolId = SP.SchoolId AND S.SchoolId = SP.SchoolId

group by S.SchoolName,SchoolCategory,AssessmentGrade,subject,AcademicYear

UNION

SELECT count(EconomicDisadvantaged) Total_Test_Count,S.SchoolName, 'E' As TotalType,AcademicYear As Academicyear,

'Total Tests' AS 'Satisfactory Standard'	,SchoolCategory, AssessmentGrade ,SP.subject AS Subject

FROM [dbo].rpt_StudentAssessmentPerformance AS SP

INNER JOIN schools S ON S.SchoolId = SP.SchoolId and EconomicDisadvantaged = 1

group by S.SchoolName,SchoolCategory,AssessmentGrade, subject,AcademicYear	

UNION

/*# Satisfactory Standard or Above*/

Select  count([EconomicDisadvantaged]) Total_Test_Count,S.SchoolName,'T' As TotalType,AcademicYear As Academicyear,

'# Satisfactory Standard or Above' AS 'Satisfactory Standard',SchoolCategory ,   AssessmentGrade ,SP.subject AS Subject

from rpt_StudentAssessmentPerformance SP

Inner join [StandardsLookup] L On SP.AssessedGradeLevelDescriptorId = L.GradeLevelDescriptorID

and SP.AcademicSubjectDescriptorId = L.AcademicSubjectDescriptorID and Score >= L.Approach

Inner Join Schools S ON S.SchoolId = SP.SchoolId

group by S.SchoolName,SchoolCategory,AssessmentGrade,sp.subject,AcademicYear

UNION

Select  count([EconomicDisadvantaged]) Total_Test_Count,S.SchoolName,'T' As TotalType,AcademicYear As Academicyear,

'# Satisfactory Standard or Above' AS 'Satisfactory Standard',SchoolCategory ,   AssessmentGrade ,SP.subject AS Subject

from rpt_StudentAssessmentPerformance SP

Inner join [StandardsLookup] L On SP.AssessedGradeLevelDescriptorId = L.GradeLevelDescriptorID

and SP.AcademicSubjectDescriptorId = L.AcademicSubjectDescriptorID and Score >= L.Approach

and [EconomicDisadvantaged] = 1

Inner Join Schools S ON S.SchoolId = SP.SchoolId

group by S.SchoolName,SchoolCategory,AssessmentGrade,sp.subject,AcademicYear

/* # Postsecondary Readiness Standard or Above*/

UNION

Select  count([EconomicDisadvantaged]) Total_Test_Count,S.SchoolName,'T' As TotalType,AcademicYear As Academicyear,

'# Postsecondary Readiness Standard or Above' AS 'Satisfactory Standard',SchoolCategory ,   AssessmentGrade ,SP.subject AS Subject

from rpt_StudentAssessmentPerformance SP

Inner join [StandardsLookup] L On SP.AssessedGradeLevelDescriptorId = L.GradeLevelDescriptorID

and SP.AcademicSubjectDescriptorId = L.AcademicSubjectDescriptorID and Score >= L.Meet

Inner Join Schools S ON S.SchoolId = SP.SchoolId

group by S.SchoolName,SchoolCategory,AssessmentGrade,sp.subject,AcademicYear

UNION

Select  count([EconomicDisadvantaged]) Total_Test_Count,S.SchoolName,'T' As TotalType,AcademicYear As Academicyear,

'# Postsecondary Readiness Standard or Above' AS 'Satisfactory Standard',SchoolCategory ,   AssessmentGrade ,SP.subject AS Subject

from rpt_StudentAssessmentPerformance SP

Inner join [StandardsLookup] L On SP.AssessedGradeLevelDescriptorId = L.GradeLevelDescriptorID

and SP.AcademicSubjectDescriptorId = L.AcademicSubjectDescriptorID and Score >= L.Meet

and [EconomicDisadvantaged] = 1

Inner Join Schools S ON S.SchoolId = SP.SchoolId

group by S.SchoolName,SchoolCategory,AssessmentGrade,sp.subject,AcademicYear

/* # Advanced Standard*/

UNION

Select  count([EconomicDisadvantaged]) Total_Test_Count,S.SchoolName,'T' As TotalType,AcademicYear As Academicyear,

'# Advanced Standard' AS 'Satisfactory Standard',SchoolCategory ,   AssessmentGrade ,SP.subject AS Subject

from rpt_StudentAssessmentPerformance SP

Inner join [StandardsLookup] L On SP.AssessedGradeLevelDescriptorId = L.GradeLevelDescriptorID

and SP.AcademicSubjectDescriptorId = L.AcademicSubjectDescriptorID and Score >= L.Master

Inner Join Schools S ON S.SchoolId = SP.SchoolId

group by S.SchoolName,SchoolCategory,AssessmentGrade,sp.subject,AcademicYear

UNION

Select  count([EconomicDisadvantaged]) Total_Test_Count,S.SchoolName,'T' As TotalType,AcademicYear As Academicyear,

'# Advanced Standard' AS 'Satisfactory Standard',SchoolCategory ,   AssessmentGrade ,SP.subject AS Subject

from rpt_StudentAssessmentPerformance SP

Inner join [StandardsLookup] L On SP.AssessedGradeLevelDescriptorId = L.GradeLevelDescriptorID

and SP.AcademicSubjectDescriptorId = L.AcademicSubjectDescriptorID and Score >= L.Master

and [EconomicDisadvantaged] = 1

Inner Join Schools S ON S.SchoolId = SP.SchoolId

group by S.SchoolName,SchoolCategory,AssessmentGrade,sp.subject,AcademicYear

/*********************   EOC  ************************/

UNION

SELECT count([EconomicDisadvantaged]) Total_Test_Count,S.SchoolName,'T' As TotalType,AcademicYear As Academicyear,

'Total Tests' AS 'Satisfactory Standard',SchoolCategory ,   AssessmentGrade ,SP.subject AS Subject

FROM [dbo].rpt_StudentAssessmentPerformance AS SP

INNER JOIN schools S ON S.SchoolId = SP.SchoolId AND S.SchoolId = SP.SchoolId

group by S.SchoolName,SchoolCategory,AssessmentGrade,subject,AcademicYear

UNION

SELECT count(EconomicDisadvantaged) Total_Test_Count,S.SchoolName, 'E' As TotalType,AcademicYear As Academicyear,

'Total Tests' AS 'Satisfactory Standard'	,SchoolCategory, AssessmentGrade ,SP.subject AS Subject

FROM [dbo].rpt_StudentAssessmentPerformance AS SP

INNER JOIN schools S ON S.SchoolId = SP.SchoolId and EconomicDisadvantaged = 1

group by S.SchoolName,SchoolCategory,AssessmentGrade, subject,AcademicYear	

UNION

/*# Satisfactory Standard or Above*/

Select  count([EconomicDisadvantaged]) Total_Test_Count,S.SchoolName,'T' As TotalType,AcademicYear As Academicyear,

'# Satisfactory Standard or Above' AS 'Satisfactory Standard',SchoolCategory ,   AssessmentGrade ,SP.subject AS Subject

from rpt_StudentAssessmentPerformance SP

Inner join StandardsLookupEOC L On SP.subject = L.subject and Score >= L.Approach

Inner Join Schools S ON S.SchoolId = SP.SchoolId

group by S.SchoolName,SchoolCategory,AssessmentGrade,sp.subject,AcademicYear

UNION

Select  count([EconomicDisadvantaged]) Total_Test_Count,S.SchoolName,'E' As TotalType,AcademicYear As Academicyear,

'# Satisfactory Standard or Above' AS 'Satisfactory Standard',SchoolCategory ,   AssessmentGrade ,SP.subject AS Subject

from rpt_StudentAssessmentPerformance SP

Inner join StandardsLookupEOC L On SP.subject = L.subject and Score >= L.Approach

and [EconomicDisadvantaged] = 1

Inner Join Schools S ON S.SchoolId = SP.SchoolId

group by S.SchoolName,SchoolCategory,AssessmentGrade,sp.subject,AcademicYear

/* # Postsecondary Readiness Standard or Above*/

UNION

Select  count([EconomicDisadvantaged]) Total_Test_Count,S.SchoolName,'T' As TotalType,AcademicYear As Academicyear,

'# Postsecondary Readiness Standard or Above' AS 'Satisfactory Standard',SchoolCategory ,   AssessmentGrade ,SP.subject AS Subject

from rpt_StudentAssessmentPerformance SP

Inner join StandardsLookupEOC L On SP.subject = L.subject and Score >= L.Meet

Inner Join Schools S ON S.SchoolId = SP.SchoolId

group by S.SchoolName,SchoolCategory,AssessmentGrade,sp.subject,AcademicYear

UNION

Select  count([EconomicDisadvantaged]) Total_Test_Count,S.SchoolName,'E' As TotalType,AcademicYear As Academicyear,

'# Postsecondary Readiness Standard or Above' AS 'Satisfactory Standard',SchoolCategory ,   AssessmentGrade ,SP.subject AS Subject

from rpt_StudentAssessmentPerformance SP

Inner join StandardsLookupEOC L On SP.subject = L.subject and Score >= L.Meet

and [EconomicDisadvantaged] = 1

Inner Join Schools S ON S.SchoolId = SP.SchoolId

group by S.SchoolName,SchoolCategory,AssessmentGrade,sp.subject,AcademicYear

/* # Advanced Standard*/

UNION

Select  count([EconomicDisadvantaged]) Total_Test_Count,S.SchoolName,'T' As TotalType,AcademicYear As Academicyear,

'# Advanced Standard' AS 'Satisfactory Standard',SchoolCategory ,   AssessmentGrade ,SP.subject AS Subject

from rpt_StudentAssessmentPerformance SP

Inner join StandardsLookupEOC L On SP.subject = L.subject and Score >= L.Master

Inner Join Schools S ON S.SchoolId = SP.SchoolId

group by S.SchoolName,SchoolCategory,AssessmentGrade,sp.subject,AcademicYear

UNION

Select  count([EconomicDisadvantaged]) Total_Test_Count,S.SchoolName,'E' As TotalType,AcademicYear As Academicyear,

'# Advanced Standard' AS 'Satisfactory Standard',SchoolCategory ,   AssessmentGrade ,SP.subject AS Subject

from rpt_StudentAssessmentPerformance SP

Inner join StandardsLookupEOC L On SP.subject = L.subject and Score >= L.Master

and [EconomicDisadvantaged] = 1

Inner Join Schools S ON S.SchoolId = SP.SchoolId

group by S.SchoolName,SchoolCategory,AssessmentGrade,sp.subject,AcademicYear



GO

CREATE View [dbo].[VW_State_Assessment_Student_Performance_All_New]

AS

Select * , 

Case 

When AssessmentGrade = 'First grade' Then 'Grade 1 ' + Subject

When AssessmentGrade = 'Second grade' Then 'Grade 2 ' + Subject

When AssessmentGrade = 'Third grade' Then 'Grade 3 ' + Subject

When AssessmentGrade = 'Fourth grade' Then 'Grade 4 ' + Subject

When AssessmentGrade = 'Fifth grade' Then 'Grade 5 ' + Subject

When AssessmentGrade = 'Sixth grade' Then 'Grade 6 ' + Subject

When AssessmentGrade = 'Seventh grade' Then 'Grade 7 ' + Subject

When AssessmentGrade = 'Eighth grade' Then 'Grade 8 ' + Subject

When AssessmentGrade = 'Ninth grade' Then 'Grade 9 ' + Subject

Else

Subject 

End As 'SubjectGrade', 'Data' As 'Copy'

from VW_State_Assessment_Student_Performance_New

UNION ALL

Select * , 

Case 

When AssessmentGrade = 'First grade' Then 'Grade 1 ' + Subject

When AssessmentGrade = 'Second grade' Then 'Grade 2 ' + Subject

When AssessmentGrade = 'Third grade' Then 'Grade 3 ' + Subject

When AssessmentGrade = 'Fourth grade' Then 'Grade 4 ' + Subject

When AssessmentGrade = 'Fifth grade' Then 'Grade 5 ' + Subject

When AssessmentGrade = 'Sixth grade' Then 'Grade 6 ' + Subject

When AssessmentGrade = 'Seventh grade' Then 'Grade 7 ' + Subject

When AssessmentGrade = 'Eighth grade' Then 'Grade 8 ' + Subject

When AssessmentGrade = 'Ninth grade' Then 'Grade 9 ' + Subject

Else

Subject 

End As 'SubjectGrade', 'Total' As 'Copy'

from VW_State_Assessment_Student_Performance_New



/*

UNION

Select sum(Total_Test_Count) AS Total_Test_Count, 'ALL SCHOOLS' As SchoolName ,TotalType,'AY-2015-2016' AS Academicyear, 

[Satisfactory Standard],'ALL' As SchoolCategory,

'ALL Assessment', 'ALL Subject' As Subject , 'ALL' AS SubjectGrade

from VW_State_Assessment_Student_Performance_New 

group by SchoolName, Academicyear,SchoolCategory,TotalType,[Satisfactory Standard]

*/



GO


CREATE VIEW [dbo].[vw_assessment_early_warning_system]
AS

SELECT a.AcademicYear, a.SchoolCategory, a.SchoolId, a.SchoolName, a.StudentUSI, a.Student_StateUniqueID,a.StudentName, A.Grade,A.GradeLevel, a.TotalPresent, a.PerOfPresent ,
	[Subject], Isnull(NumericSubjectGrade,0) As NumericSubjectGrade, isnull(Score.STAARResult,0) AS STAARResult
	, isnull(Score.iStation,0) AS iStation
	, Isnull(LexileMeasureScore,'') as LexileMeasureScore
	,isnull(IstationTier,0) as IstationTier ,ProgramName 
	,CASE WHEN LexileMeasureScore Like 'BR%' THEN Convert(decimal(20,2),dbo.udf_GetNumeric(LexileMeasureScore)) * -1
		  WHEN LexileMeasureScore = 'BR' THEN 0
		  WHEN LexileMeasureScore <> '' THEN Convert(decimal(20,2),dbo.udf_GetNumeric(LexileMeasureScore))
	END AS 'Lexile'
FROM 
(
	SELECT 'Attendance' AS ReportType, AcademicYear, SchoolCategory, SchoolId, SchoolName, StudentUSI,Student_StateUniqueID, StudentName, Grade, GradeLevel
	, SUM(ExecusedAbsence+UnExecusedAbsence) AS TotalAbsent
	, SUM(Tardy+Present) AS TotalPresent
	,CONVERT(decimal(5,2), ROUND((SUM(Present+Tardy) * 100.00) /SUM(ExecusedAbsence+UnExecusedAbsence+Tardy+Present), 2)) AS PerOfPresent,ProgramName
	FROM [dbo].[rpt_StudentsAttendanceCalendar]
	GROUP BY AcademicYear, SchoolCategory,ProgramName, SchoolId, SchoolName, StudentUSI,Student_StateUniqueID, StudentName, Grade, GradeLevel
) as A
LEFT JOIN
( 
	SELECT AcademicYear, SchoolId, SchoolCategory, SchoolName, StudentUSI,Student_StateUniqueID, StudentName, [Subject], NumericSubjectGrade, 
	MAX(STAARResult) AS STAARResult, MAX(iStation) AS iStation, MAX(LexileMeasureScore) AS LexileMeasureScore, MAX(IstationTier) AS IstationTier
	FROM (
		SELECT AcademicYear, Pvt.SchoolId, Pvt.SchoolCategory, Pvt.SchoolName, Pvt.StudentUSI,PVT.Student_StateUniqueID, Pvt.StudentName, [Subject], NumericSubjectGrade, 
		Pvt.[State Assessment] AS STAARResult, Pvt.[iStation Assessment] AS iStation, LexileMeasureScore,IstationTier as IstationTier
		FROM
		( 
			 SELECT SA.AcademicYear, SA.SchoolId, Sch.SchoolCategory, Sch.SchoolName, SA.StudentUSI,SA.Student_StateUniqueID, Stu.StudentName, [Subject], AssessmentCategory,
			 NumericSubjectGrade, ISNULL(CAST(ScaleScore AS decimal(12,5)),0) AS ScaleScore, LexileMeasureScore,IstationTier as IstationTier
			 FROM rpt_SpecialAssessment AS SA 
			 INNER JOIN dbo.Schools AS Sch ON SA.SchoolID = Sch.SchoolID
			 INNER JOIN DBO.Students AS Stu ON Stu.Student_StateUniqueID = SA.Student_StateUniqueID
			 WHERE performancebasetype IN('Advanced','iStation') 
			 and AssessmentCategory in ('State Assessment','iStation Assessment') 
			 AND Subject in('Mathematics','Reading','Writing')
		 ) AS P 
		 PIVOT ( AVG(P.ScaleScore)  FOR P.AssessmentCategory IN ( [State Assessment],[iStation Assessment]) ) AS Pvt
	) AS A
	GROUP BY AcademicYear, SchoolId, SchoolCategory, SchoolName, StudentUSI, Student_StateUniqueID, StudentName, [Subject],  NumericSubjectGrade
)  AS Score
on Score.Student_StateUniqueID = A.Student_StateUniqueID and score.AcademicYear = a.AcademicYear
-- and Score.SchoolId = Atten.SchoolId and Score.ProgramName=Atten.ProgramName


GO

CREATE View [dbo].[vw_Performance_LevelBy_Demographic_Assessment]
AS

SELECT AcademicYear, Pvt.SchoolId, Pvt.SchoolCategory, Pvt.SchoolName, Pvt.Student_StateUniqueID, Pvt.StudentName, ProgramName, [Subject], NumericSubjectGrade,
Gender,Race,HispanicLatinoEthnicity,AtRisk,EconomicDisadvantaged,HomeLess,Immigrant,Migrant,LimitedEnglishProficiency,GradeLevel,overage,
ISNULL(Pvt.[Advanced],0) AS Advanced, 
ISNULL(Pvt.[Satisfactory],0) AS Satisfactory,AssessmentGrade, AssessmentTitle, AssessmentType
FROM  
( 
	SELECT SA.AcademicYear, SA.SchoolId, Sch.SchoolCategory, Sch.SchoolName, SA.Student_StateUniqueID, Stu.StudentName, SA.ProgramName, SA.[Subject], SA.AssessmentTitle,
	AssessmentType, NumericSubjectGrade, PerformanceBaseType, PerformanceLevelMet,
	SH.Gender,SH.Race,SH.HispanicLatinoEthnicity,SH.AtRisk,SH.EconomicDisadvantaged,SH.HomeLess,SH.Immigrant,SH.Migrant,SH.LimitedEnglishProficiency,SH.GradeLevel,SH.overage,SA.AssessmentGrade
	FROM rpt_SpecialAssessment AS SA 
	INNER JOIN dbo.Schools AS Sch ON SA.SchoolID = Sch.SchoolID
	INNER JOIN DBO.Students_History AS SH ON SH.Student_StateUniqueID = SA.Student_StateUniqueID AND SH.AcademicYear = SA.AcademicYear
	INNER JOIN DBO.Students AS Stu ON Stu.Student_StateUniqueID = SA.Student_StateUniqueID
where PerformanceBaseType <> 'iStation'
) AS P 
PIVOT ( SUM(P.PerformanceLevelMet)  FOR P.PerformanceBaseType IN ( [Advanced],[Satisfactory]) ) AS Pvt

GO



CREATE VIEW [dbo].[V_LocalAssessments]
AS
SELECT * FROM (
SELECT 
  ROW_NUMBER() OVER(PARTITION BY SchoolDistrictId,SchoolId,StudentUSI,AcademicSubject ORDER BY AdministrationDate DESC,Result DESC,ID ASC) AS RowNo,
  *
FROM rpt_LocalAssessments 
where ResultDataType='Integer' 
) AS Temp WHERE RowNo=1

GO



CREATE VIEW [dbo].[V_LocalAssessments_Score]
AS
SELECT *
FROM (
	SELECT ROW_NUMBER() OVER (
			PARTITION BY SchoolDistrictId
			,SchoolId
			,StudentUSI
			,AcademicSubject ORDER BY AdministrationDate DESC
				,Result DESC
				,ID ASC
			) AS RowNo
		,*
	FROM rpt_LocalAssessments
	-- WHERE ResultDataType = 'Integer'
		--and StudentUSI=5996 and AcademicSubject='Mathematics'  
	) AS TEMP
CROSS APPLY (
	SELECT AVG(ScoreResult) AS AvgScore
	FROM rpt_LocalAssessments
	WHERE SchoolDistrictId = TEMP.SchoolDistrictId
		AND SchoolId = TEMP.SchoolId
		AND StudentUSI = TEMP.StudentUSI
		AND AcademicSubject = TEMP.AcademicSubject
		--AND ResultDataType = 'Integer'
	GROUP BY SchoolDistrictId
		,SchoolId
		,StudentUSI
		,AcademicSubject
	) AS AvgS
WHERE RowNo = 1



GO



CREATE view [dbo].[vw_assessment_special_program] AS

Select Atten.AcademicYear

, Atten.SchoolCategory

, Atten.SchoolId

, Atten.SchoolName

, Atten.ProgramName

, Atten.StudentUSI

, Atten.Student_StateUniqueID

, Atten.StudentName

, Atten.TotalAbsent

, Atten.TotalPresent

, Atten.PerOfPresent

, Atten.StateOffense

, Atten.SchoolCodeofConduct

, Atten.SchoolViolation
, [Subject], NumericSubjectGrade ,CAResult,BenchMarkResult,STAARResult,SnapshotResult, [iStation], LexileMeasureScore -- ,performancebasetype

FROM (

SELECT a.AcademicYear, a.SchoolCategory, a.SchoolId, a.SchoolName, a.ProgramName, a.StudentUSI,a.Student_StateUniqueID, a.StudentName, a.TotalAbsent, a.TotalPresent, a.PerOfPresent , b.StateOffense, b.SchoolCodeofConduct, b.SchoolViolation 

FROM 

(

SELECT 'Attendance' AS ReportType, AcademicYear, SchoolCategory, SchoolId, SchoolName, ProgramName, StudentUSI, Student_StateUniqueID,StudentName

, SUM(ExecusedAbsence+UnExecusedAbsence) AS TotalAbsent

, SUM(Tardy+Present) AS TotalPresent

,CONVERT(decimal(5,2), ROUND((SUM(Present+Tardy) * 100.00) /SUM(ExecusedAbsence+UnExecusedAbsence+Tardy+Present), 2)) AS PerOfPresent

FROM [dbo].[rpt_StudentsAttendanceCalendar] 

GROUP BY AcademicYear, SchoolCategory, SchoolId, SchoolName, ProgramName, StudentUSI,Student_StateUniqueID, StudentName

) a left join 

(

SELECT 'Discipline' AS ReportType, AcademicYear, SchoolCategory, DI.SchoolId as SchoolId, DI.SchoolName, Stu.ProgramName, DI.Student_StateUniqueID,stu.StudentName

,SUM(SchoolViolation) AS SchoolViolation, SUM(StateOffense) AS StateOffense, SUM(SchoolCodeofConduct) AS SchoolCodeofConduct, SUM(Others) AS Others

, SUM(SchoolViolation)+SUM(StateOffense)+SUM(SchoolCodeofConduct)+SUM(Others) AS TotalDisciplineIncidents

FROM [dbo].[rpt_StudentsDisciplineIncidents] AS DI

INNER JOIN dbo.Students AS Stu ON Stu.Student_StateUniqueID = DI.Student_StateUniqueID AND Stu.SchoolId = DI.SchoolId

GROUP BY AcademicYear, SchoolCategory, DI.SchoolId, DI.SchoolName, Stu.ProgramName, DI.Student_StateUniqueID, stu.StudentName

) b

on a.Student_StateUniqueID=b.Student_StateUniqueID and a.SchoolId = b.SchoolId and a.ProgramName=b.ProgramName

) AS Atten
LEFT JOIN
( 
	SELECT AcademicYear, Pvt.SchoolId, Pvt.SchoolCategory, Pvt.SchoolName, Pvt.StudentUSI,Pvt.Student_StateUniqueID, Pvt.StudentName, ProgramName, [Subject], NumericSubjectGrade,Pvt.[Common Assessment] AS CAResult, 
	Pvt.[BenchMark] AS BenchMarkResult, Pvt.[State Assessment] AS STAARResult, Pvt.[Snapshot] AS SnapshotResult, [iStation Assessment] AS iStation, LexileMeasureScore--, performancebasetype
	FROM  
	( 
		SELECT SA.AcademicYear, SA.SchoolId, Sch.SchoolCategory, Sch.SchoolName, SA.StudentUSI,SA.Student_StateUniqueID, Stu.StudentName, SA.ProgramName, [Subject]
		, AssessmentCategory
		, NumericSubjectGrade, ISNULL(CAST(RawScore AS INT),0) AS RawScore, LexileMeasureScore
		--,performancebasetype
		FROM rpt_SpecialAssessment AS SA 
		INNER JOIN dbo.Schools AS Sch ON SA.SchoolID = Sch.SchoolID
		INNER JOIN DBO.Students AS Stu ON Stu.Student_StateUniqueID = SA.Student_StateUniqueID
	WHERE performancebasetype IN('Advanced','iStation','Satisfactory') 
	) AS P 
	PIVOT ( AVG(P.RawScore)  FOR P.AssessmentCategory IN ( [Common Assessment],[BenchMark],[State Assessment],[Snapshot], [iStation Assessment]) ) AS Pvt
)  AS Score

on Score.Student_StateUniqueID = Atten.Student_StateUniqueID and  score.AcademicYear=Atten.AcademicYear
GO






